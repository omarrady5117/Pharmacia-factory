'use strict';
const CATS = {
  meds: { t: 'الأدوية', u: 'علبة', f: [['name', 'اسم الدواء'], ['batch', 'رقم الباتش'], ['exp', 'تاريخ الانتهاء', 'date'], ['prod', 'تاريخ الإنتاج', 'date']] },
  alu: { t: 'الألومنيوم', u: 'كجم', f: [['name', 'الاسم'], ['made', 'التصنيع لـ']] },
  pvc: { t: 'PVC', u: 'كجم', f: [['name', 'الاسم'], ['made', 'التصنيع لـ']] },
  stk: { t: 'الاستيكرات', u: 'عدد', f: [['name', 'الاسم'], ['made', 'التصنيع لـ']] },
  box: { t: 'العلب', u: 'عدد', f: [['name', 'الاسم'], ['made', 'التصنيع لـ']] },
  sup: { t: 'المستلزمات', u: 'قطعة', f: [['name', 'الصنف']] }
};
const ACT = {
  'login.ok': 'دخول', 'login.fail': 'محاولة دخول فاشلة', 'item.add': 'إضافة صنف', 'move.in': 'إضافة كمية', 'move.out': 'صرف كمية',
  'item.delete': 'حذف صنف', 'user.create': 'إنشاء حساب', 'user.password.reset': 'إعادة تعيين كلمة مرور', 'user.role': 'تغيير نوع الحساب', 'user.perms': 'تغيير صلاحيات حساب', 'login.unlock': 'فك قفل الدخول', 'user.owner': 'تحديد مالك النظام',
  'user.active': 'تفعيل / إيقاف حساب', 'password.change': 'تغيير كلمة المرور', 'import': 'استيراد بيانات', 'backup': 'نسخة احتياطية', 'restore': 'استرجاع نسخة احتياطية', 'invoice.add': 'فاتورة صرف', 'receipt.add': 'إذن استلام'
};
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const today = () => { const d = new Date(), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
const nf = n => Number(n).toLocaleString('en-US');
const r2 = n => Math.round(n * 100) / 100;
const fmt = t => new Date(t).toLocaleString('ar-EG');
let me = null, db = { items: {} }, lastBackup = null, tab = 'meds', q = '', pendingPw = '', rep = { mode: 'month', month: today().slice(0, 7), year: today().slice(0, 4), from: today().slice(0, 7) + '-01', to: today(), q: '' };
const isOwner = () => !!me && !!me.owner;
const can = p => !!me && (!!me.owner || (me.perms || []).includes(p));
const PERMS = [['edit', 'تعديل المخزون (إضافة وصرف وحذف الأصناف)', 'تعديل'], ['audit', 'الاطلاع على سجل التدقيق', 'سجل التدقيق'], ['users', 'إدارة الحسابات (إضافة مستخدمين وتعديل صلاحياتهم)', 'إدارة الحسابات']];
const permsOf = o => PERMS.map(p => p[0]).filter(k => o['p_' + k]);
const isAdmin = () => can('edit');
const unitOf = it => it.unit || CATS[it.cat].u;

async function api(path, method = 'GET', body) {
  const r = await fetch('/api' + path, {
    method, credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'fetch' },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  let j = {}; try { j = await r.json(); } catch (e) {}
  if (r.status === 401 && path !== '/login') { me = null; showLogin('انتهت الجلسة، سجّل الدخول من جديد'); throw new Error('انتهت الجلسة'); }
  if (!r.ok) throw new Error(j.error || 'حدث خطأ');
  return j;
}
async function loadState() { const s = await api('/state'); db.items = s.items; lastBackup = s.lastBackup || null; }

/* ---------- login / change password ---------- */
function setLg(mode, msg) {
  $('#lg').hidden = false; $('#lg').dataset.mode = mode; $('#lgErr').textContent = '';
  $('#lgMsg').textContent = msg || (mode === 'login' ? 'سجّل الدخول للمتابعة' : 'لازم تختار كلمة مرور جديدة (8 حروف على الأقل)');
  $('#lgF').innerHTML = mode === 'login'
    ? '<input id="un" autocomplete="username" autocapitalize="none" spellcheck="false" placeholder="اسم المستخدم" dir="ltr"><input id="pw" type="password" autocomplete="current-password" placeholder="كلمة المرور" dir="ltr">'
    : '<input id="np1" type="password" autocomplete="new-password" placeholder="كلمة المرور الجديدة" dir="ltr"><input id="np2" type="password" autocomplete="new-password" placeholder="أعد كتابتها" dir="ltr">';
  $('#lgGo').textContent = mode === 'login' ? 'دخول' : 'حفظ وتسجيل الدخول';
  const f = $(mode === 'login' ? '#un' : '#np1'); if (f) f.focus();
}
function showLogin(msg) {
  me = null; pendingPw = ''; $('#view').innerHTML = ''; $('#tabs').innerHTML = ''; $('#roleTxt').textContent = '';
  $('#pwBtn').hidden = true; $('#roleBtn').hidden = true;
  setLg('login', msg);
}
async function doLg() {
  const err = $('#lgErr'); err.textContent = '';
  try {
    if ($('#lg').dataset.mode === 'login') {
      const un = $('#un').value.trim(), pw = $('#pw').value;
      if (!un || !pw) { err.textContent = 'اكتب اسم المستخدم وكلمة المرور'; return; }
      const r = await api('/login', 'POST', { username: un, password: pw });
      me = r.user;
      if (me.mustChange) { pendingPw = pw; setLg('change'); return; }
      await enter();
    } else {
      const a = $('#np1').value, b = $('#np2').value;
      if (a.length < 8) { err.textContent = 'كلمة المرور لازم تكون 8 حروف على الأقل'; return; }
      if (a !== b) { err.textContent = 'كلمتا المرور غير متطابقتين'; return; }
      await api('/password', 'POST', { old: pendingPw, new: a });
      pendingPw = ''; me.mustChange = false; await enter();
    }
  } catch (e) { err.textContent = e.message; }
}
async function enter() {
  await loadState(); tab = 'meds'; q = '';
  $('#lg').hidden = true; $('#lgF').innerHTML = '';
  $('#pwBtn').hidden = false; $('#roleBtn').hidden = false;
  render();
}

/* ---------- helpers ---------- */
function expTag(d) {
  if (!d) return '';
  const days = Math.floor((new Date(d) - new Date(today())) / 864e5);
  if (days < 0) return '<span class="tag t-bad">منتهي</span>';
  if (days <= 90) return `<span class="tag t-warn">باقي ${days} يوم</span>`;
  return '<span class="tag t-ok">سليم</span>';
}
function form(title, fields, ok, okText) {
  $('#frm').innerHTML = `<h3>${esc(title)}</h3>${fields.map(f => `<label>${esc(f[1])}</label>${f[2] === 'checks'
    ? f[3].map(o => `<label class="ck"><input type="checkbox" name="p_${o[0]}" ${(f[4] || []).includes(o[0]) ? 'checked' : ''}> ${esc(o[1])}</label>`).join('')
    : f[2] === 'select'
    ? `<select name="${f[0]}">${f[3].map(o => Array.isArray(o) ? `<option value="${esc(o[0])}">${esc(o[1])}</option>` : `<option>${esc(o)}</option>`).join('')}</select>`
    : `<input name="${f[0]}" type="${f[2] || 'text'}" ${f[3] || ''} ${f[4] === 'opt' ? '' : 'required'} autocomplete="off">`}`).join('')}<div class="dbtn"><button class="btn" value="ok">${okText || 'حفظ'}</button><button class="btn sec" value="x" formnovalidate>إلغاء</button></div>`;
  const d = $('#dlg'); d.showModal();
  $('#frm').onsubmit = async e => {
    e.preventDefault();
    if (e.submitter && e.submitter.value === 'ok') {
      const o = {}; new FormData($('#frm')).forEach((v, k) => o[k] = typeof v === 'string' ? v.trim() : v);
      try { await ok(o); d.close(); } catch (err) { alert(err.message); }
    } else d.close();
  };
}
async function refresh() { await loadState(); render(); }

/* ---------- views ---------- */
function tabs() {
  const ks = [...Object.keys(CATS), 'doc', 'rep', ...(can('users') ? ['usr'] : []), ...(can('audit') ? ['aud'] : []), ...(can('edit') || can('users') ? ['bak'] : [])];
  const lab = { doc: 'الفواتير والاستلام', rep: 'التقارير', usr: 'الحسابات', aud: 'سجل التدقيق', bak: 'النسخ الاحتياطي' };
  $('#tabs').innerHTML = ks.map(k => `<button role="tab" type="button" data-tab="${k}" aria-selected="${k === tab}">${lab[k] || CATS[k].t}</button>`).join('');
  $('#roleTxt').textContent = `${me.username} — ${isOwner() ? 'المالك (كل الصلاحيات)' : (PERMS.filter(p => can(p[0])).map(p => p[2]).join(' + ') || 'مشاهدة فقط')}`;
}
function render() {
  if (!me) return;
  tabs();
  if (tab === 'doc') return renderDocs();
  if (tab === 'rep') return renderRep();
  if (tab === 'usr') return renderUsers();
  if (tab === 'aud') return renderAudit();
  if (tab === 'bak') return renderBak();
  const c = CATS[tab], items = db.items[tab] || [];
  const list = items.filter(it => !q || Object.values(it).join(' ').toLowerCase().includes(q.toLowerCase()));
  const total = items.reduce((s, x) => s + x.qty, 0);
  let h = `<div class="sum"><div><b>${items.length}</b><span>عدد الأصناف</span></div>${tab === 'sup' ? '' : `<div><b>${nf(total)} ${c.u}</b><span>إجمالي الكمية</span></div>`}</div>
 <div class="bar"><input id="q" type="search" placeholder="ابحث في ${esc(c.t)}..." value="${esc(q)}">${isAdmin() ? '<button class="btn" type="button" data-add>+ صنف جديد</button>' : ''}</div>`;
  if (!list.length) h += '<div class="wrap"><div class="empty">لا توجد أصناف</div></div>';
  else {
    h += `<div class="wrap"><table><thead><tr>${c.f.map(f => `<th>${f[1]}</th>`).join('')}${tab === 'meds' ? '<th>الحالة</th>' : ''}<th>الكمية</th>${isAdmin() ? '<th>حركة</th>' : ''}</tr></thead><tbody>`;
    h += list.map(it => `<tr>${c.f.map(f => `<td>${esc(it[f[0]])}</td>`).join('')}${tab === 'meds' ? `<td>${expTag(it.exp)}</td>` : ''}<td class="qty">${nf(it.qty)} <small>${esc(unitOf(it))}</small>${it.per ? `<br><small>= ${+(it.qty / it.per).toFixed(2)} كيس</small>` : ''}</td>${isAdmin() ? `<td class="act"><button class="in" type="button" data-mv="in" data-id="${it.id}" title="إضافة">+</button><button class="out" type="button" data-mv="out" data-id="${it.id}" title="صرف">−</button><button type="button" data-del="${it.id}" title="حذف">🗑</button></td>` : ''}</tr>`).join('');
    h += '</tbody></table></div>';
  }
  h += '<p class="note">كل إضافة أو صرف بيتسجل تلقائيًا في تقرير الشهر وفي سجل التدقيق باسم من عمله.</p>';
  $('#view').innerHTML = h;
  const qi = $('#q'); qi.oninput = e => { q = e.target.value; const p = qi.selectionStart; render(); const n = $('#q'); n.focus(); n.setSelectionRange(p, p); };
}
/* ---------- reports (month / year / range, search, excel) ---------- */
const rowText = l => [l.date, CATS[l.cat].t, l.name, l.batch, l.made, l.doc_name || '', l.user, l.note || '', l.type === 'in' ? 'وارد' : 'صرف'].join(' ').toLowerCase();
const lastDay = (y, m) => new Date(Number(y), Number(m), 0).getDate();
function repRange() {
  if (rep.mode === 'year') return [rep.year + '-01-01', rep.year + '-12-31'];
  if (rep.mode === 'range') return [rep.from, rep.to];
  const [y, m] = rep.month.split('-'); return [rep.month + '-01', rep.month + '-' + String(lastDay(y, m)).padStart(2, '0')];
}
let repRows = [], repTrunc = false;
async function renderRep() {
  const modes = [['month', 'شهر'], ['year', 'سنة كاملة'], ['range', 'من تاريخ إلى تاريخ']];
  $('#view').innerHTML = `<div class="rp"><select id="rmode">${modes.map(m => `<option value="${m[0]}" ${rep.mode === m[0] ? 'selected' : ''}>${m[1]}</option>`).join('')}</select>`
    + (rep.mode === 'month' ? `<input id="rmon" type="month" value="${esc(rep.month)}">` : rep.mode === 'year' ? `<input id="ryear" type="number" min="2000" max="2100" value="${esc(rep.year)}">` : `<input id="rfrom" type="date" value="${esc(rep.from)}"><input id="rto" type="date" value="${esc(rep.to)}">`)
    + `</div><div class="rp"><input id="rq" type="search" style="flex:3 1 220px" placeholder="ابحث: اسم صنف، باتش، فاتورة، مستخدم، أو تاريخ (2026-11-06)" value="${esc(rep.q)}"><input id="rday" type="date" title="يوم معين"><button class="btn" type="button" id="rxl">تصدير Excel</button></div><div id="repOut"></div>`;
  $('#rmode').onchange = e => { rep.mode = e.target.value; renderRep(); };
  const bind = (id, key) => { const el = $('#' + id); if (el) el.onchange = e => { if (e.target.value) { rep[key] = e.target.value; loadRep(); } }; };
  bind('rmon', 'month'); bind('ryear', 'year'); bind('rfrom', 'from'); bind('rto', 'to');
  $('#rq').oninput = e => { rep.q = e.target.value; repBody(); };
  $('#rday').onchange = e => { rep.q = e.target.value; $('#rq').value = rep.q; repBody(); };
  $('#rxl').onclick = () => { const [f, t] = repRange(); const a = document.createElement('a'); a.href = `/api/report.xlsx?from=${f}&to=${t}&q=${encodeURIComponent(rep.q.trim())}`; document.body.appendChild(a); a.click(); a.remove(); };
  await loadRep();
}
async function loadRep() {
  const [f, t] = repRange(), out = $('#repOut'); if (!out) return;
  if (!f || !t || f > t) { out.innerHTML = '<div class="warnbox">اختار فترة صحيحة (تاريخ البداية قبل النهاية)</div>'; return; }
  out.innerHTML = '<div class="empty">جاري التحميل...</div>';
  try { const r = await api('/moves?from=' + f + '&to=' + t); repRows = r.moves; repTrunc = r.truncated; } catch (e) { return; }
  if (tab !== 'rep') return;
  repBody();
}
function repBody() {
  const out = $('#repOut'); if (!out) return;
  const qq = rep.q.trim().toLowerCase(), rows = qq ? repRows.filter(l => rowText(l).includes(qq)) : repRows;
  const inn = rows.filter(l => l.type === 'in').length, by = new Map();
  rows.forEach(l => { const k = [l.cat, l.name, l.batch, l.unit].join('|'), x = by.get(k) || { l, i: 0, o: 0 }; if (l.type === 'in') x.i += l.qty; else x.o += l.qty; by.set(k, x); });
  const [f, t] = repRange();
  let h = `<p class="note">الفترة: ${esc(f)} إلى ${esc(t)}${qq ? ' — نتائج البحث عن «' + esc(rep.q.trim()) + '»' : ''}</p>` + (repTrunc ? '<div class="warnbox">الفترة فيها حركات كتير: اتعرض أول 100,000 بس. قصّر الفترة.</div>' : '')
    + `<div class="sum"><div><b>${inn}</b><span>حركات وارد</span></div><div><b>${rows.length - inn}</b><span>حركات صرف</span></div><div><b>${rows.length}</b><span>إجمالي الحركات</span></div></div><h2>ملخص لكل صنف</h2>`;
  const arr = [...by.values()].sort((a, b) => b.o - a.o);
  h += arr.length ? `<div class="wrap"><table><thead><tr><th>القسم</th><th>الصنف</th><th>الباتش</th><th>وارد</th><th>صرف</th></tr></thead><tbody>${arr.map(x => `<tr><td>${esc(CATS[x.l.cat].t)}</td><td>${esc(x.l.name)}</td><td>${esc(x.l.batch)}</td><td class="qty">${nf(r2(x.i))} <small>${esc(x.l.unit || '')}</small></td><td class="qty">${nf(r2(x.o))} <small>${esc(x.l.unit || '')}</small></td></tr>`).join('')}</tbody></table></div>` : '<div class="wrap"><div class="empty">لا توجد حركات</div></div>';
  const LIM = 500, show = rows.slice().reverse().slice(0, LIM);
  h += `<h2>سجل الحركات${rows.length > LIM ? ` <small>(آخر ${LIM} من ${rows.length} — صدّر Excel للكل)</small>` : ''}</h2>`;
  h += show.length ? `<div class="wrap"><table><thead><tr><th>التاريخ</th><th>القسم</th><th>الصنف</th><th>الباتش</th><th>النوع</th><th>الكمية</th><th>المستند</th><th>بواسطة</th><th>ملاحظة</th></tr></thead><tbody>${show.map(l => `<tr><td>${esc(l.date)}</td><td>${esc(CATS[l.cat].t)}</td><td>${esc(l.name)}</td><td>${esc(l.batch)}</td><td><span class="tag ${l.type === 'in' ? 't-ok' : 't-bad'}">${l.type === 'in' ? 'وارد' : 'منصرف'}</span></td><td class="qty">${nf(l.qty)} <small>${esc(l.unit || '')}</small></td><td>${l.doc_id ? `<button class="lnk" type="button" data-doc="${l.doc_id}">${esc(l.doc_name)}</button>` : ''}</td><td>${esc(l.user)}</td><td>${esc(l.note)}</td></tr>`).join('')}</tbody></table></div>` : '<div class="wrap"><div class="empty">لا توجد حركات</div></div>';
  out.innerHTML = h;
}

/* ---------- documents: invoices (out) and receipts (in) ---------- */
let docs = [], docKind = '', docQ = '', lnSeq = 0;
async function renderDocs() {
  $('#view').innerHTML = '<div class="empty">جاري التحميل...</div>';
  try { docs = (await api('/docs')).docs; } catch (e) { return; }
  if (tab !== 'doc') return;
  const kinds = [['', 'الكل'], ['invoice', 'فواتير الصرف'], ['receipt', 'إذون الاستلام']];
  $('#view').innerHTML = `<div class="bar"><h2 style="margin:0;flex:1">الفواتير والاستلام</h2>${isAdmin() ? '<button class="btn" type="button" data-newdoc="invoice">+ فاتورة صرف</button><button class="btn" type="button" data-newdoc="receipt">+ إذن استلام</button>' : ''}</div>
  <div class="rp"><select id="dk">${kinds.map(k => `<option value="${k[0]}" ${docKind === k[0] ? 'selected' : ''}>${k[1]}</option>`).join('')}</select><input id="dq" type="search" style="flex:3 1 200px" placeholder="ابحث باسم المستند أو التاريخ أو المستخدم..." value="${esc(docQ)}"></div><div id="docOut"></div>`;
  $('#dk').onchange = e => { docKind = e.target.value; docList(); };
  $('#dq').oninput = e => { docQ = e.target.value; docList(); };
  docList();
}
function docList() {
  const qq = docQ.trim().toLowerCase();
  const list = docs.filter(d => (!docKind || d.kind === docKind) && (!qq || [d.name, d.date, d.user, CATS[d.cat].t].join(' ').toLowerCase().includes(qq)));
  $('#docOut').innerHTML = list.length ? `<div class="wrap"><table><thead><tr><th>التاريخ</th><th>النوع</th><th>الاسم</th><th>القسم</th><th>عدد الأصناف</th><th>بواسطة</th><th></th></tr></thead><tbody>${list.map(d => `<tr><td>${esc(d.date)}</td><td><span class="tag ${d.kind === 'invoice' ? 't-bad' : 't-ok'}">${d.kind === 'invoice' ? 'فاتورة صرف' : 'إذن استلام'}</span></td><td>${esc(d.name)}</td><td>${esc(CATS[d.cat].t)}</td><td>${d.n}</td><td>${esc(d.user)}</td><td class="act"><button type="button" data-doc="${d.id}">فتح</button></td></tr>`).join('')}</tbody></table></div>` : '<div class="wrap"><div class="empty">لا توجد مستندات</div></div>';
}
function bigDlg(html) {
  let d = $('#dlg2'); if (!d) { d = document.createElement('dialog'); d.id = 'dlg2'; d.className = 'dwide'; document.body.appendChild(d); }
  d.innerHTML = html; if (!d.open) d.showModal(); return d;
}
async function openDoc(id) {
  const r = await api('/docs/' + id), d = r.doc, c = CATS[d.cat];
  const cols = d.cat === 'meds' ? [['batch', 'الباتش'], ['exp', 'تاريخ الانتهاء'], ['prod', 'تاريخ الإنتاج']] : d.cat === 'sup' ? [] : [['made', 'التصنيع لـ']];
  bigDlg(`<h3>${esc(d.name)}</h3><p class="note">${d.kind === 'invoice' ? 'فاتورة صرف' : 'إذن استلام'} — القسم: ${esc(c.t)} — التاريخ: ${esc(d.date)} — بواسطة: ${esc(d.user)}${d.note ? ' — ' + esc(d.note) : ''}</p>
   <div class="wrap"><table><thead><tr><th>الصنف</th>${cols.map(x => `<th>${x[1]}</th>`).join('')}<th>الكمية</th></tr></thead><tbody>${r.lines.map(l => `<tr><td>${esc(l.name)}</td>${cols.map(x => `<td>${esc(l[x[0]])}</td>`).join('')}<td class="qty">${nf(l.qty)} <small>${esc(l.unit || '')}</small></td></tr>`).join('')}</tbody></table></div>
   <div class="dbtn"><button class="btn sec" type="button" data-close>إغلاق</button></div>`);
}
const lineRow = (kind, cat) => {
  if (kind === 'invoice') { const id = 'dlB' + (++lnSeq); return `<div class="ln" data-ln><input class="ln-name" data-f="name" list="dlNames" placeholder="اسم الدواء (اكتب للبحث أو اختار)" autocomplete="off"><input class="ln-batch" data-f="batch" list="${id}" placeholder="رقم الباتش" autocomplete="off"><datalist id="${id}"></datalist><input data-f="qty" type="number" min="0" step="any" placeholder="الكمية (${esc(CATS.meds.u)})"><button class="rm" type="button" data-rmline title="حذف السطر">✕</button><small class="ln-hint"></small></div>`; }
  const c = CATS[cat];
  return `<div class="ln" data-ln>${c.f.map(f => `<div class="fl"><span>${esc(f[1])}</span><input data-f="${f[0]}" type="${f[2] || 'text'}" ${f[0] === 'name' ? 'list="dlNames"' : ''} autocomplete="off"></div>`).join('')}<div class="fl"><span>الكمية (${esc(c.u)})</span><input data-f="qty" type="number" min="0" step="any"></div>${cat === 'sup' ? '<div class="fl"><span>الوحدة (لو صنف جديد)</span><select data-f="unit"><option>قطعة</option><option>كرتونة</option><option>كيس</option></select></div><label class="ck"><input type="checkbox" data-f="bag"> بالأكياس</label>' : ''}<button class="rm" type="button" data-rmline title="حذف السطر">✕</button></div>`;
};
function resetLines(d) {
  const kind = d.dataset.kind, cat = d.dataset.cat;
  $('#dlNames').innerHTML = [...new Set((db.items[cat] || []).map(i => i.name))].map(n => `<option value="${esc(n)}">`).join('');
  $('#dlines').innerHTML = lineRow(kind, cat);
}
async function openDocForm(kind) {
  await loadState();
  const d = bigDlg(`<h3>${kind === 'invoice' ? 'فاتورة صرف أدوية' : 'إذن استلام'}</h3>
   <label>${kind === 'invoice' ? 'اسم الفاتورة' : 'اسم الإذن (مثلًا: استلام من المورد س)'}</label><input id="dn" autocomplete="off">
   <div class="grid2"><div><label>التاريخ</label><input id="dd" type="date" value="${today()}"></div><div><label>ملاحظة (اختياري)</label><input id="dnote" autocomplete="off"></div></div>
   ${kind === 'receipt' ? `<label>القسم</label><select id="dcat">${Object.keys(CATS).map(k => `<option value="${k}">${esc(CATS[k].t)}</option>`).join('')}</select>` : ''}
   <datalist id="dlNames"></datalist><h4>الأصناف</h4><div id="dlines"></div>
   <button class="btn sec" type="button" data-addline>+ إضافة صنف</button>
   <div class="dbtn"><button class="btn" type="button" data-savedoc>${kind === 'invoice' ? 'حفظ وخصم من المخزون' : 'حفظ وإضافة للمخزون'}</button><button class="btn sec" type="button" data-close>إلغاء</button></div>`);
  d.dataset.kind = kind; d.dataset.cat = 'meds'; resetLines(d);
}
async function saveDoc(d) {
  const kind = d.dataset.kind;
  const lines = [...d.querySelectorAll('[data-ln]')].map(r => { const o = {}; r.querySelectorAll('[data-f]').forEach(i => { o[i.dataset.f] = i.type === 'checkbox' ? i.checked : i.value.trim(); }); return o; })
    .filter(o => Object.entries(o).some(([k, v]) => k !== 'unit' && k !== 'bag' && v));
  const body = { name: $('#dn').value.trim(), date: $('#dd').value, note: $('#dnote').value.trim(), lines };
  if (kind === 'receipt') body.cat = d.dataset.cat;
  await api(kind === 'invoice' ? '/invoices' : '/receipts', 'POST', body);
  d.close(); alert('تم الحفظ وتحديث المخزون'); tab = 'doc'; await loadState(); render();
}
function lnUpdate(row) {
  const nm = row.querySelector('.ln-name').value.trim().toLowerCase(), bt = row.querySelector('.ln-batch').value.trim().toLowerCase();
  const same = (db.items.meds || []).filter(i => i.name.trim().toLowerCase() === nm);
  row.querySelector('datalist').innerHTML = same.map(i => `<option value="${esc(i.batch)}">متاح ${i.qty} — ينتهي ${esc(i.exp)}</option>`).join('');
  const it = same.find(i => (i.batch || '').trim().toLowerCase() === bt), h = row.querySelector('.ln-hint');
  h.textContent = !nm ? '' : !bt ? (same.length ? 'اختار رقم الباتش' : 'الدواء ده مش موجود في المخزون') : it ? `المتاح: ${it.qty} ${unitOf(it)} — ينتهي ${it.exp}` : 'مفيش باتش بالرقم ده للدواء ده';
  h.style.color = (nm && bt && !it) ? 'var(--bad)' : '';
}
document.addEventListener('input', e => { const r = e.target.closest && e.target.closest('.ln'); if (r && r.closest('dialog') && r.closest('dialog').dataset.kind === 'invoice') lnUpdate(r); });
document.addEventListener('change', e => { if (e.target.id === 'dcat') { const d = $('#dlg2'); d.dataset.cat = e.target.value; resetLines(d); } });
const permTags = u => u.owner ? '<span class="tag t-ok">المالك — كل الصلاحيات</span>' : (u.perms.length ? u.perms.map(k => `<span class="tag t-ok">${esc(PERMS.find(p => p[0] === k)[2])}</span>`).join(' ') : '<span class="tag">مشاهدة فقط</span>');
const canManage = u => !u.owner && (isOwner() || !u.perms.includes('users'));
async function renderUsers() {
  $('#view').innerHTML = '<div class="empty">جاري التحميل...</div>';
  let us, locks = []; try { us = (await api('/users')).users; locks = (await api('/locks')).locks; await loadState(); } catch (e) { return; }
  if (tab !== 'usr') return;
  const lockHtml = '<h2>محاولات الدخول المقفولة</h2>' + (locks.length
    ? `<div class="bar"><span style="flex:1" class="note">بعد كل 5 محاولات غلط بيتقفل 5 دقايق، وكل مرة تانية المدة بتزيد 5 دقايق (لحد ساعة). وبيتصفّر بعد ساعة من غير غلط، أو بعد دخول صح.</span><button class="btn" type="button" data-unlockall>فك الكل</button></div><div class="wrap"><table><thead><tr><th>الحساب</th><th>الجهاز (IP)</th><th>باقي</th><th></th></tr></thead><tbody>${locks.map(l => `<tr><td dir="ltr">${l.user ? esc(l.user) : 'كل الحسابات من الجهاز ده'}</td><td dir="ltr">${esc(l.ip)}</td><td>${l.minutes} د <small>(المرة ${l.level})</small></td><td class="act"><button type="button" data-unlock="${esc(l.key)}">فك</button></td></tr>`).join('')}</tbody></table></div>`
    : '<div class="wrap"><div class="empty">مفيش حاجة مقفولة دلوقتي</div></div>');
  const stale = !lastBackup || (Date.now() - new Date(lastBackup)) > 36 * 3600e3;
  let h = stale ? `<div class="warnbox">⚠️ ${lastBackup ? 'آخر نسخة احتياطية: ' + esc(fmt(lastBackup)) + ' (أقدم من 36 ساعة)' : 'لم تتم أي نسخة احتياطية بعد'}. بلّغ مسؤول السيرفر.</div>` : `<div class="okbox">آخر نسخة احتياطية: ${esc(fmt(lastBackup))}</div>`;
  h += `<div class="bar"><h2 style="margin:0;flex:1">الحسابات</h2><button class="btn" type="button" data-newuser>+ حساب جديد</button></div>
 <div class="wrap"><table><thead><tr><th>المستخدم</th><th>الصلاحيات</th><th>الحالة</th><th></th></tr></thead><tbody>${us.map(u => `<tr><td dir="ltr">${esc(u.username)}</td><td>${permTags(u)}</td><td>${u.active ? '<span class="tag t-ok">شغال</span>' : '<span class="tag t-bad">موقوف</span>'}${u.mustChange ? ' <small>(لم يغيّر كلمة المرور)</small>' : ''}</td><td class="act">${u.username === me.username ? '<small>حسابك</small>' : !canManage(u) ? '<small>—</small>' : `<button type="button" data-upw="${u.id}" data-un="${esc(u.username)}">كلمة مرور جديدة</button><button type="button" data-uperm="${u.id}" data-un="${esc(u.username)}" data-p="${esc(u.perms.join(','))}">الصلاحيات</button><button type="button" data-uact="${u.id}" data-to="${u.active ? '0' : '1'}">${u.active ? 'إيقاف' : 'تفعيل'}</button>`}</td></tr>`).join('')}</tbody></table></div>
${lockHtml}
 <p class="note">الحساب الموقوف لا يستطيع الدخول، وسجله القديم يفضل محفوظ. كل حساب جديد لازم يغيّر كلمة المرور عند أول دخول.</p>${isOwner() ? `
 <h2>استيراد بيانات النسخة التجريبية</h2><p class="note">لو كنت مدخل بيانات في النسخة التجريبية وعندك ملف نسخة احتياطية (JSON) منها. الاستيراد بيشتغل مرة واحدة فقط والنظام فاضي من الأصناف.</p><input id="imp" type="file" accept=".json,application/json">` : ''}`;
  $('#view').innerHTML = h;
}
async function renderBak() {
  $('#view').innerHTML = '<div class="empty">جاري التحميل...</div>';
  try { await loadState(); } catch (e) { return; }
  if (tab !== 'bak') return;
  const stale = !lastBackup || (Date.now() - new Date(lastBackup)) > 36 * 3600e3;
  $('#view').innerHTML = (stale ? `<div class="warnbox">⚠️ ${lastBackup ? 'آخر نسخة احتياطية: ' + esc(fmt(lastBackup)) + ' (أقدم من 36 ساعة)' : 'لم تتم أي نسخة احتياطية بعد'}</div>` : `<div class="okbox">آخر نسخة احتياطية: ${esc(fmt(lastBackup))}</div>`) +
    `<div class="bar"><h2 style="margin:0;flex:1">النسخ الاحتياطي</h2><button class="btn" id="bakNow" type="button">خد نسخة احتياطية الآن</button></div>
 <p class="note">النسخة التلقائية بتتاخد كل يوم الساعة 2 الفجر. لو الكمبيوتر كان مقفول وقتها أو الهارد الخارجي مكانش متوصل، دوس الزرار ده. الهارد لازم يفضل متوصل بالسيرفر.</p>`;
}
async function renderAudit() {
  $('#view').innerHTML = '<div class="empty">جاري التحميل...</div>';
  let r; try { r = await api('/audit?limit=200'); } catch (e) { return; }
  if (tab !== 'aud') return;
  $('#view').innerHTML = `<div class="bar"><h2 style="margin:0;flex:1">سجل التدقيق (${nf(r.total)} عملية)</h2><button class="btn" type="button" data-verify>فحص سلامة السجل</button></div><div id="vres"></div>
 <div class="wrap"><table><thead><tr><th>الوقت</th><th>المستخدم</th><th>العملية</th><th>الصنف / الهدف</th><th>التفاصيل</th></tr></thead><tbody>${r.rows.map(x => `<tr><td>${esc(fmt(x.ts))}</td><td dir="ltr">${esc(x.user)}</td><td>${esc(ACT[x.action] || x.action)}</td><td>${esc(x.target)}</td><td><small class="ltr">${esc(x.detail)}</small></td></tr>`).join('')}</tbody></table></div><p class="note">بيظهر آخر 200 عملية. الوقت مسجّل من ساعة السيرفر ولا يمكن تعديل السجل من داخل البرنامج.</p>`;
}

/* ---------- events ---------- */
$('#lgGo').addEventListener('click', doLg);
$('#lg').addEventListener('keydown', e => { if (e.key === 'Enter') doLg(); });
document.addEventListener('change', async e => {
  if (e.target.id !== 'imp' || !isOwner()) return;
  const f = e.target.files[0]; if (!f) return;
  try {
    const o = JSON.parse(await f.text());
    if (!confirm('استيراد هذا الملف؟ بيتم مرة واحدة فقط ولا يمكن التراجع عنه.')) { e.target.value = ''; return; }
    const r = await api('/import', 'POST', o);
    alert(`تم استيراد ${r.items} صنف و${r.moves} حركة`); await refresh();
  } catch (err) { alert(err.message === 'Unexpected end of JSON input' || err instanceof SyntaxError ? 'الملف غير صالح' : err.message); e.target.value = ''; }
});
document.addEventListener('click', async e => {
  const t = e.target.closest('button'); if (!t || !me) return;
  try {
    if (t.dataset.tab) { tab = t.dataset.tab; q = ''; if (CATS[tab]) await loadState(); render(); return; }
    if (t.id === 'roleBtn') { try { await api('/logout', 'POST', {}); } catch (e2) {} showLogin(); return; }
    if (t.id === 'pwBtn') {
      form('تغيير كلمة المرور', [['old', 'كلمة المرور الحالية', 'password'], ['nw', 'كلمة المرور الجديدة (8 حروف على الأقل)', 'password', 'minlength="8"'], ['nw2', 'أعد كتابتها', 'password']], async o => {
        if (o.nw !== o.nw2) throw new Error('كلمتا المرور غير متطابقتين');
        await api('/password', 'POST', { old: o.old, new: o.nw }); alert('تم تغيير كلمة المرور');
      });
      return;
    }
    if (t.dataset.close !== undefined) { t.closest('dialog').close(); return; }
    if (t.dataset.doc) { await openDoc(t.dataset.doc); return; }
    if (!me.owner && !(me.perms || []).length) return;
    if (t.dataset.newdoc) { await openDocForm(t.dataset.newdoc); return; }
    if (t.dataset.addline !== undefined) { const d = t.closest('dialog'); $('#dlines').insertAdjacentHTML('beforeend', lineRow(d.dataset.kind, d.dataset.cat)); return; }
    if (t.dataset.rmline !== undefined) { if (document.querySelectorAll('#dlines [data-ln]').length > 1) t.closest('[data-ln]').remove(); return; }
    if (t.dataset.savedoc !== undefined) { t.disabled = true; try { await saveDoc(t.closest('dialog')); } finally { t.disabled = false; } return; }
    if (t.id === 'bakNow') {
      t.disabled = true;
      try { const r = await api('/backup', 'POST', {}); alert('تمت النسخة الاحتياطية: ' + r.file); } finally { await renderBak(); }
      return;
    }
    if (t.dataset.unlock !== undefined || t.hasAttribute('data-unlockall')) {
      await api('/locks/clear', 'POST', t.hasAttribute('data-unlockall') ? {} : { key: t.dataset.unlock });
      alert('تم فك القفل'); await renderUsers(); return;
    }
    if (t.dataset.verify !== undefined) {
      const r = await api('/audit/verify');
      $('#vres').innerHTML = r.ok ? `<div class="okbox">السجل سليم (${nf(r.count)} عملية متسلسلة بدون أي تعديل)</div>` : `<div class="warnbox">⚠️ تم اكتشاف تلاعب أو تلف في السجل عند العملية رقم ${r.brokenAt}. بلّغ المسؤول فورًا.</div>`;
      return;
    }
    if (t.hasAttribute('data-add')) {
      const extra = tab === 'sup' ? [['unit', 'الوحدة', 'select', ['قطعة', 'كرتونة', 'كيس']]] : [];
      form('إضافة صنف — ' + CATS[tab].t, [...CATS[tab].f, ...extra, ['qty', 'الكمية (' + (tab === 'sup' ? 'بالوحدة المختارة' : CATS[tab].u) + ')', 'number', 'min="0" step="any"']],
        async o => { await api('/items', 'POST', { ...o, cat: tab, qty: Number(o.qty) }); await refresh(); });
      return;
    }
    if (t.dataset.mv) {
      const it = (db.items[tab] || []).find(x => x.id === Number(t.dataset.id)); if (!it) return;
      const isIn = t.dataset.mv === 'in';
      form((isIn ? 'إضافة كمية — ' : 'صرف كمية — ') + it.name, [['qty', 'الكمية (' + (it.per ? 'بالقطعة أو الكيس' : unitOf(it)) + ')', 'number', 'min="0.01" step="any"'], ...(it.per ? [['bag', 'الإدخال بـ', 'select', ['قطعة', 'كيس']]] : []), ['note', 'ملاحظة (اختياري)', 'text', '', 'opt']],
        async o => { await api(`/items/${it.id}/move`, 'POST', { type: t.dataset.mv, qty: Number(o.qty), bag: o.bag, note: o.note }); await refresh(); });
      return;
    }
    if (t.dataset.del !== undefined) {
      const it = (db.items[tab] || []).find(x => x.id === Number(t.dataset.del));
      if (it && confirm('حذف "' + it.name + '" نهائيًا؟ (العملية هتتسجل في سجل التدقيق)')) { await api('/items/' + it.id, 'DELETE'); await refresh(); }
      return;
    }
    if (t.hasAttribute('data-newuser')) {
      form('حساب جديد', [['username', 'اسم المستخدم (إنجليزي وأرقام)', 'text', 'pattern="[A-Za-z0-9._-]{3,32}" dir="ltr"'], ['password', 'كلمة مرور مؤقتة (8 حروف على الأقل)', 'text', 'minlength="8" dir="ltr"'], ['perms', 'الصلاحيات (اختار اللي تديه للحساب ده، ولو مفيش يبقى مشاهدة فقط)', 'checks', PERMS.filter(p => isOwner() || p[0] !== 'users')]],
        async o => { await api('/users', 'POST', { username: o.username, password: o.password, perms: permsOf(o) }); await renderUsers(); });
      return;
    }
    if (t.dataset.upw) {
      form('كلمة مرور جديدة لـ ' + t.dataset.un, [['password', 'كلمة مرور مؤقتة (8 حروف على الأقل)', 'text', 'minlength="8" dir="ltr"']],
        async o => { await api('/users/' + t.dataset.upw, 'PATCH', { password: o.password }); alert('تم. المستخدم هيختار كلمة مرور جديدة عند أول دخول.'); await renderUsers(); });
      return;
    }
    if (t.dataset.uperm) {
      const cur = t.dataset.p ? t.dataset.p.split(',') : [];
      form('صلاحيات ' + t.dataset.un, [['perms', 'اختار الصلاحيات (والتغيير بيسري فورًا)', 'checks', PERMS.filter(p => isOwner() || p[0] !== 'users'), cur]],
        async o => { await api('/users/' + t.dataset.uperm, 'PATCH', { perms: permsOf(o) }); await renderUsers(); });
      return;
    }
    if (t.dataset.uact) { if (confirm(t.dataset.to === '0' ? 'إيقاف هذا الحساب؟' : 'تفعيل هذا الحساب؟')) { await api('/users/' + t.dataset.uact, 'PATCH', { active: t.dataset.to === '1' }); await renderUsers(); } }
  } catch (err) { if (err.message !== 'انتهت الجلسة') alert(err.message); }
});

(async () => {
  try {
    const r = await api('/me'); me = r.user;
    if (me.mustChange) { try { await api('/logout', 'POST', {}); } catch (e) {} showLogin(); } else await enter();
  } catch (e) { if (!me) showLogin(); }
})();
