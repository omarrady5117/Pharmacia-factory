'use strict';
// Pharmacia inventory server. Node.js 22.13+ only, no npm packages needed.
const http = require('node:http'), fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const ROOT = __dirname;
const cfg = { port: 3000, dataDir: 'data', backupDir: '', backupKeepDays: 30, lockStepMinutes: 5 };
try { Object.assign(cfg, JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'))); }
catch (e) { console.error('config.json problem:', e.message); process.exit(1); }
const DATA = path.resolve(ROOT, cfg.dataDir);
fs.mkdirSync(DATA, { recursive: true });
const log = m => { try { fs.appendFileSync(path.join(DATA, 'server.log'), new Date().toISOString() + ' ' + m + '\n'); } catch (e) {} console.log(m); };

// ---------- database ----------
const db = new DatabaseSync(path.join(DATA, 'pharmacia.db'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA synchronous=FULL; PRAGMA busy_timeout=5000;');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE,
  role TEXT NOT NULL CHECK(role IN('admin','user')), salt TEXT NOT NULL, hash TEXT NOT NULL,
  active INTEGER NOT NULL DEFAULT 1, must_change INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS items(id INTEGER PRIMARY KEY, cat TEXT NOT NULL, name TEXT NOT NULL, batch TEXT, exp TEXT,
  code TEXT, made TEXT, unit TEXT NOT NULL, per REAL, qty REAL NOT NULL CHECK(qty>=0), created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS moves(id INTEGER PRIMARY KEY, ts TEXT NOT NULL, date TEXT NOT NULL, cat TEXT NOT NULL,
  item_id INTEGER, name TEXT NOT NULL, type TEXT NOT NULL CHECK(type IN('in','out')), qty REAL NOT NULL,
  unit TEXT, note TEXT, user TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS moves_date ON moves(date);
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, ts TEXT NOT NULL, user TEXT NOT NULL, action TEXT NOT NULL,
  target TEXT NOT NULL, detail TEXT NOT NULL, prev_hash TEXT NOT NULL, hash TEXT NOT NULL);
CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit BEGIN SELECT RAISE(ABORT,'audit is append-only'); END;
CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit BEGIN SELECT RAISE(ABORT,'audit is append-only'); END;
CREATE TABLE IF NOT EXISTS meta(k TEXT PRIMARY KEY, v TEXT);
`);
try { db.exec('ALTER TABLE users ADD COLUMN owner INTEGER NOT NULL DEFAULT 0'); } catch (e) { /* column already exists */ }
try { db.exec("ALTER TABLE users ADD COLUMN perms TEXT NOT NULL DEFAULT ''"); } catch (e) { /* column already exists */ }
for (const sql of ['ALTER TABLE items ADD COLUMN prod TEXT', 'ALTER TABLE moves ADD COLUMN doc_id INTEGER', 'ALTER TABLE moves ADD COLUMN info TEXT']) { try { db.exec(sql); } catch (e) { /* already there */ } }
db.exec(`CREATE TABLE IF NOT EXISTS docs(id INTEGER PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN('invoice','receipt')), name TEXT NOT NULL, date TEXT NOT NULL, cat TEXT NOT NULL, note TEXT, user TEXT NOT NULL, ts TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS moves_doc ON moves(doc_id);`);
const all = (sql, ...a) => db.prepare(sql).all(...a);
const one = (sql, ...a) => db.prepare(sql).get(...a);
const run = (sql, ...a) => db.prepare(sql).run(...a);
function tx(fn) {
  db.exec('BEGIN IMMEDIATE');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { try { db.exec('ROLLBACK'); } catch (_) {} throw e; }
}

// ---------- audit log (append-only, hash-chained) ----------
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
function audit(user, action, target, detail) {
  const prev = (one('SELECT hash FROM audit ORDER BY id DESC LIMIT 1') || {}).hash || '0';
  const ts = new Date().toISOString(), t = target || '', d = detail == null ? '' : JSON.stringify(detail);
  run('INSERT INTO audit(ts,user,action,target,detail,prev_hash,hash) VALUES(?,?,?,?,?,?,?)',
    ts, user, action, t, d, prev, sha([prev, ts, user, action, t, d].join('|')));
}
function verifyAudit() {
  let prev = '0', n = 0;
  for (const r of all('SELECT * FROM audit ORDER BY id')) {
    if (r.prev_hash !== prev || r.hash !== sha([prev, r.ts, r.user, r.action, r.target, r.detail].join('|'))) return { ok: false, count: n, brokenAt: r.id };
    prev = r.hash; n++;
  }
  return { ok: true, count: n };
}

// ---------- passwords ----------
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
const DUMMY = { salt: '00', hash: hashPw('dummy', '00') };
function okPw(pw, u) {
  const a = Buffer.from(hashPw(pw, u.salt), 'hex'), b = Buffer.from(u.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
const tempPw = () => crypto.randomBytes(9).toString('base64url');
function createUser(username, pw, role, mustChange, actor, perms) {
  const salt = crypto.randomBytes(16).toString('hex');
  const r = run('INSERT INTO users(username,role,salt,hash,must_change,created_at,perms) VALUES(?,?,?,?,?,?,?)',
    username, role, salt, hashPw(pw, salt), mustChange ? 1 : 0, new Date().toISOString(), perms || '');
  audit(actor, 'user.create', username, { role, perms: perms || '' });
  return Number(r.lastInsertRowid);
}
function setPw(id, pw, mustChange) {
  const salt = crypto.randomBytes(16).toString('hex');
  run('UPDATE users SET salt=?,hash=?,must_change=? WHERE id=?', salt, hashPw(pw, salt), mustChange ? 1 : 0, id);
}

// ---------- backup (VACUUM INTO gives a consistent copy even while the server runs) ----------
function backup(actor = 'system') {
  if (!cfg.backupDir) throw new Error('backupDir is empty in config.json');
  fs.mkdirSync(cfg.backupDir, { recursive: true });
  const d = new Date(), p = n => String(n).padStart(2, '0');
  let name = `pharmacia-${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}_${p(d.getHours())}${p(d.getMinutes())}${p(d.getSeconds())}.db`;
  for (let k = 2; fs.existsSync(path.join(cfg.backupDir, name)); k++) name = name.replace(/(-\d+)?\.db$/, '-' + k + '.db'); // two backups in the same second
  const dest = path.join(cfg.backupDir, name);
  db.exec(`VACUUM INTO '${dest.replace(/'/g, "''")}'`);
  const t = new DatabaseSync(dest);
  const chk = Object.values(t.prepare('PRAGMA integrity_check').get())[0];
  t.close();
  if (chk !== 'ok') { fs.unlinkSync(dest); throw new Error('backup integrity check failed'); }
  const limit = Date.now() - cfg.backupKeepDays * 864e5;
  for (const f of fs.readdirSync(cfg.backupDir)) {
    if (!/^pharmacia-[\d_-]+\.db$/.test(f)) continue;
    const fp = path.join(cfg.backupDir, f);
    if (fs.statSync(fp).mtimeMs < limit) fs.unlinkSync(fp);
  }
  tx(() => {
    run("INSERT INTO meta(k,v) VALUES('last_backup',?) ON CONFLICT(k) DO UPDATE SET v=excluded.v", new Date().toISOString());
    audit(actor, 'backup', name, null);
  });
  return dest;
}

// ---------- command line modes ----------
const argv = process.argv.slice(2);
if (argv[0] === '--backup') {
  try { log('Backup OK: ' + backup()); process.exit(0); }
  catch (e) { log('BACKUP FAILED: ' + e.message); process.exit(1); }
}
if (argv[0] === '--reset-password') {
  const u = one('SELECT id,username FROM users WHERE username=?', argv[1] || '');
  if (!u) { console.error('User not found: ' + (argv[1] || '')); process.exit(1); }
  const pw = tempPw();
  tx(() => { setPw(u.id, pw, true); run('UPDATE users SET active=1 WHERE id=?', u.id); audit('system', 'user.password.reset', u.username, { via: 'console' }); });
  console.log('\nTemporary password for ' + u.username + ':  ' + pw + '\nThe user must choose a new password at first login.\n');
  process.exit(0);
}

if (argv[0] === '--make-owner') {
  upgradeUsers();
  const u = one('SELECT id,username,role FROM users WHERE username=?', argv[1] || '');
  if (!u || u.role !== 'admin') { console.error('لازم يكون حساب Admin موجود: ' + (argv[1] || '')); process.exit(1); }
  tx(() => { run("UPDATE users SET owner=0, perms=REPLACE(perms,',users','') WHERE owner=1"); run('UPDATE users SET owner=1 WHERE id=?', u.id); audit('system', 'user.owner', u.username, { via: 'console' }); });
  console.log('\nOwner is now: ' + u.username + '\n'); process.exit(0);
}

// ---------- first run ----------
if (!one('SELECT 1 AS x FROM users')) {
  const pw = tempPw();
  tx(() => createUser('admin', pw, 'admin', true, 'system', 'edit,audit,users'));
  const f = path.join(DATA, 'FIRST-RUN-PASSWORD.txt');
  fs.writeFileSync(f, `Username: admin\nTemporary password: ${pw}\nYou must change it at first login. This file is deleted automatically after that.\n`);
  log('First run: created account "admin". Temporary password is in ' + f);
}
upgradeUsers();

// ---------- permissions ----------
const PERMS = ['edit', 'audit', 'users'];
const permList = u => u.owner ? PERMS.slice() : String(u.perms || '').split(',').filter(p => PERMS.includes(p));
const can = (u, p) => permList(u).includes(p);
const roleOf = perms => perms.length ? 'admin' : 'user';
function upgradeUsers() { // one-time upgrade of databases created by older versions
  if (!one('SELECT 1 AS x FROM users WHERE owner=1')) {
    const f = one("SELECT id,username FROM users WHERE role='admin' AND active=1 ORDER BY id LIMIT 1");
    if (f) { tx(() => { run('UPDATE users SET owner=1 WHERE id=?', f.id); audit('system', 'user.owner', f.username, { via: 'auto' }); }); log('Owner account set to ' + f.username); }
  }
  if (!one("SELECT 1 AS x FROM meta WHERE k='perms_v1'")) tx(() => {
    run("UPDATE users SET perms='edit,audit,users' WHERE owner=1");
    run("UPDATE users SET perms='edit,audit' WHERE owner=0 AND role='admin'");
    run("INSERT INTO meta(k,v) VALUES('perms_v1',?)", new Date().toISOString());
  });
}

// ---------- validation ----------
const CATS = { meds: { u: 'علبة', f: ['name', 'batch', 'exp', 'prod'] }, alu: { u: 'كجم', f: ['name', 'made'] }, pvc: { u: 'كجم', f: ['name', 'made'] },
  stk: { u: 'عدد', f: ['name', 'made'] }, box: { u: 'عدد', f: ['name', 'made'] }, sup: { u: 'قطعة', f: ['name'] } };
const SUP_UNITS = ['قطعة', 'كرتونة', 'كيس'];
class Bad extends Error { constructor(m, code) { super(m); this.code = code || 400; } }
const r2 = n => Math.round(n * 100) / 100;
function str(v, label, max = 120) {
  if (typeof v !== 'string' || !v.trim()) throw new Bad('الحقل مطلوب: ' + label);
  v = v.trim(); if (v.length > max) throw new Bad('النص طويل جدًا: ' + label); return v;
}
function optStr(v, max = 200) { if (v == null || v === '') return ''; if (typeof v !== 'string' || v.length > max) throw new Bad('نص غير صالح'); return v.trim(); }
function qtyOf(v, label = 'الكمية') {
  const n = typeof v === 'string' ? Number(v) : v;
  if (typeof n !== 'number' || !Number.isFinite(n) || n < 0 || n > 1e9) throw new Bad('قيمة غير صالحة: ' + label);
  return r2(n);
}
function dateOf(v) {
  if (typeof v !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(v) || isNaN(new Date(v))) throw new Bad('تاريخ غير صالح');
  return v;
}
function cleanItem(b) {
  const c = CATS[b && b.cat]; if (!c) throw new Bad('قسم غير معروف');
  const it = { cat: b.cat, name: '', batch: null, exp: null, prod: null, code: null, made: null, unit: c.u, per: null };
  for (const f of c.f) {
    if (f === 'exp' || f === 'prod') it[f] = dateOf(b[f]);
    else it[f] = str(b[f], f);
  }
  if (b.cat === 'sup') {
    if (b.unit != null && b.unit !== '') { if (!SUP_UNITS.includes(b.unit)) throw new Bad('وحدة غير صالحة'); it.unit = b.unit; }
  }
  if (b.per != null) { const p = qtyOf(b.per, 'per'); if (p > 0) it.per = p; }
  it.qty = qtyOf(b.qty);
  return it;
}
// ---------- documents, reports, excel ----------
const CAT_TITLES = { meds: 'الأدوية', alu: 'الألومنيوم', pvc: 'PVC', stk: 'الاستيكرات', box: 'العلب', sup: 'المستلزمات' };
const insertItem = (it, ts) => Number(run('INSERT INTO items(cat,name,batch,exp,prod,code,made,unit,per,qty,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',
  it.cat, it.name, it.batch ?? null, it.exp ?? null, it.prod ?? null, it.code ?? null, it.made ?? null, it.unit, it.per ?? null, it.qty, ts).lastInsertRowid);
const infoOf = it => { const o = {}; for (const k of ['batch', 'exp', 'prod', 'made']) if (it[k]) o[k] = it[k]; return Object.keys(o).length ? JSON.stringify(o) : null; };
const insMove = o => run('INSERT INTO moves(ts,date,cat,item_id,name,type,qty,unit,note,user,doc_id,info) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
  o.ts, o.date, o.cat, o.item_id ?? null, o.name, o.type, o.qty, o.unit ?? null, o.note ?? '', o.user, o.doc_id ?? null, o.info ?? null);
function parseInfo(r) { let o = {}; try { o = JSON.parse(r.info || '{}'); } catch (e) {} r.batch = o.batch || ''; r.exp = o.exp || ''; r.prod = o.prod || ''; r.made = o.made || ''; delete r.info; return r; }
function queryMoves(url) {
  let from, to; const mo = url.searchParams.get('month');
  if (mo) { if (!/^\d{4}-\d{2}$/.test(mo)) throw new Bad('شهر غير صالح'); from = mo + '-01'; to = mo + '-31'; }
  else { from = dateOf(url.searchParams.get('from') || ''); to = dateOf(url.searchParams.get('to') || ''); if (from > to) throw new Bad('تاريخ البداية بعد تاريخ النهاية'); }
  const rows = all('SELECT m.id,m.date,m.ts,m.cat,m.name,m.type,m.qty,m.unit,m.note,m.user,m.doc_id,m.info,d.name AS doc_name,d.kind AS doc_kind FROM moves m LEFT JOIN docs d ON d.id=m.doc_id WHERE m.date>=? AND m.date<=? ORDER BY m.date,m.id LIMIT 100001', from, to);
  const truncated = rows.length > 100000; if (truncated) rows.length = 100000;
  rows.forEach(parseInfo);
  return { rows, truncated, from, to };
}
const rowText = r => [r.date, CAT_TITLES[r.cat], r.name, r.batch, r.made, r.doc_name || '', r.user, r.note || '', r.type === 'in' ? 'وارد' : 'صرف'].join(' ').toLowerCase();
const filterRows = (rows, q) => { q = (q || '').trim().toLowerCase(); return q ? rows.filter(r => rowText(r).includes(q)) : rows; };
// minimal .xlsx writer (no dependencies): zip + a few XML parts
const xe = s => String(s).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const colL = i => { let s = ''; for (i++; i > 0; i = Math.floor((i - 1) / 26)) s = String.fromCharCode(65 + (i - 1) % 26) + s; return s; };
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = b => { let c = 0xFFFFFFFF; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; };
function zipOf(files) {
  const zlib = require('node:zlib'), now = new Date();
  const dt = ((now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1)) & 0xFFFF;
  const dd = (((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate()) & 0xFFFF;
  const out = [], cen = []; let off = 0;
  for (const f of files) {
    const nm = Buffer.from(f.name), data = Buffer.from(f.data), comp = zlib.deflateRawSync(data), crc = crc32(data);
    const lh = Buffer.alloc(30); lh.writeUInt32LE(0x04034b50, 0); lh.writeUInt16LE(20, 4); lh.writeUInt16LE(0x0800, 6); lh.writeUInt16LE(8, 8); lh.writeUInt16LE(dt, 10); lh.writeUInt16LE(dd, 12);
    lh.writeUInt32LE(crc, 14); lh.writeUInt32LE(comp.length, 18); lh.writeUInt32LE(data.length, 22); lh.writeUInt16LE(nm.length, 26);
    out.push(lh, nm, comp);
    const ch = Buffer.alloc(46); ch.writeUInt32LE(0x02014b50, 0); ch.writeUInt16LE(20, 4); ch.writeUInt16LE(20, 6); ch.writeUInt16LE(0x0800, 8); ch.writeUInt16LE(8, 10); ch.writeUInt16LE(dt, 12); ch.writeUInt16LE(dd, 14);
    ch.writeUInt32LE(crc, 16); ch.writeUInt32LE(comp.length, 20); ch.writeUInt32LE(data.length, 24); ch.writeUInt16LE(nm.length, 28); ch.writeUInt32LE(off, 42);
    cen.push(ch, nm); off += 30 + nm.length + comp.length;
  }
  const cd = Buffer.concat(cen), end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(cd.length, 12); end.writeUInt32LE(off, 16);
  return Buffer.concat([...out, cd, end]);
}
function sheetXml(head, rows, widths) {
  const cell = (v, r, c, hd) => typeof v === 'number' ? `<c r="${colL(c)}${r}"><v>${v}</v></c>` : `<c r="${colL(c)}${r}" t="inlineStr"${hd ? ' s="1"' : ''}><is><t xml:space="preserve">${xe(v ?? '')}</t></is></c>`;
  const line = (arr, r, hd) => `<row r="${r}">${arr.map((v, c) => cell(v, r, c, hd)).join('')}</row>`;
  return '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView rightToLeft="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>'
    + widths.map((w, i) => `<col min="${i + 1}" max="${i + 1}" width="${w}" customWidth="1"/>`).join('') + '</cols><sheetData>' + line(head, 1, true) + rows.map((r, i) => line(r, i + 2, false)).join('') + '</sheetData></worksheet>';
}
function xlsxOf(sheets) {
  const H = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', NS = 'http://schemas.openxmlformats.org/', R = NS + 'officeDocument/2006/relationships';
  return zipOf([
    { name: '[Content_Types].xml', data: H + '<Types xmlns="' + NS + 'package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' + sheets.map((s, i) => `<Override PartName="/xl/worksheets/sheet${i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('') + '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>' },
    { name: '_rels/.rels', data: H + '<Relationships xmlns="' + NS + 'package/2006/relationships"><Relationship Id="rId1" Type="' + R + '/officeDocument" Target="xl/workbook.xml"/></Relationships>' },
    { name: 'xl/workbook.xml', data: H + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="' + R + '"><sheets>' + sheets.map((s, i) => `<sheet name="${xe(s.name)}" sheetId="${i + 1}" r:id="rId${i + 1}"/>`).join('') + '</sheets></workbook>' },
    { name: 'xl/_rels/workbook.xml.rels', data: H + '<Relationships xmlns="' + NS + 'package/2006/relationships">' + sheets.map((s, i) => `<Relationship Id="rId${i + 1}" Type="${R}/worksheet" Target="worksheets/sheet${i + 1}.xml"/>`).join('') + `<Relationship Id="rId${sheets.length + 1}" Type="${R}/styles" Target="styles.xml"/></Relationships>` },
    { name: 'xl/styles.xml', data: H + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FFD9E8EA"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>' },
    ...sheets.map((s, i) => ({ name: `xl/worksheets/sheet${i + 1}.xml`, data: sheetXml(s.head, s.rows, s.widths) })),
  ]);
}
const findItem = (cat, it) => cat === 'meds' ? one("SELECT * FROM items WHERE cat='meds' AND lower(trim(name))=lower(?) AND lower(trim(batch))=lower(?)", it.name, it.batch)
  : cat === 'sup' ? one("SELECT * FROM items WHERE cat='sup' AND lower(trim(name))=lower(?)", it.name)
  : one('SELECT * FROM items WHERE cat=? AND lower(trim(name))=lower(?) AND lower(trim(made))=lower(?)', cat, it.name, it.made);
const docHead = body => ({ name: str(body.name, 'اسم المستند'), date: body.date ? dateOf(body.date) : localDate(), note: optStr(body.note, 300) });
const linesOf = body => { if (!Array.isArray(body.lines) || !body.lines.length) throw new Bad('أضف صنف واحد على الأقل'); if (body.lines.length > 200) throw new Bad('عدد الأصناف كبير جدًا (الحد 200)'); return body.lines; };

const localDate = () => { const d = new Date(), p = n => String(n).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
const validUser = s => typeof s === 'string' && /^[A-Za-z0-9._-]{3,32}$/.test(s);
const validPw = s => typeof s === 'string' && s.length >= 8 && s.length <= 128;

// ---------- sessions & login throttling ----------
const sessions = new Map(), IDLE = 8 * 3600e3;
function auth(req) {
  const m = /(?:^|;\s*)sid=([a-f0-9]{64})/.exec(req.headers.cookie || '');
  if (!m) return null;
  const s = sessions.get(m[1]);
  if (!s || s.exp < Date.now()) { sessions.delete(m[1]); return null; }
  const u = one('SELECT id,username,role,owner,perms,active,must_change FROM users WHERE id=?', s.uid);
  if (!u || !u.active) { sessions.delete(m[1]); return null; }
  s.exp = Date.now() + IDLE;
  return { u, token: m[1] };
}
function dropSessions(uid, except) { for (const [t, s] of sessions) if (s.uid === uid && t !== except) sessions.delete(t); }
const fails = new Map();
// Wrong passwords: after 5 failures the account is locked for 5 minutes; each further lock adds 5 more minutes (max 60).
// The level resets after one quiet hour, after a correct login, or when the owner unlocks it.
const LOCK_STEP = (Number(cfg.lockStepMinutes) || 5) * 60e3, LOCK_MAX = 60 * 60e3, QUIET = 60 * 60e3;
const isLocked = k => { const f = fails.get(k); return !!f && f.until > Date.now(); };
const lockLeftMin = (...ks) => Math.max(1, ...ks.map(k => { const f = fails.get(k); return f && f.until > Date.now() ? Math.ceil((f.until - Date.now()) / 60e3) : 0; }));
function fail(k, limit) {
  const now = Date.now(), f = fails.get(k) || { n: 0, until: 0, lvl: 0, last: 0 };
  if (f.lvl && now - Math.max(f.until, f.last) > QUIET) { f.lvl = 0; f.n = 0; f.until = 0; }
  if (f.until && f.until <= now) { f.until = 0; f.n = 0; }
  f.last = now;
  if (++f.n >= limit) { f.lvl++; f.until = now + Math.min(f.lvl * LOCK_STEP, LOCK_MAX); f.n = 0; }
  fails.set(k, f);
}
setInterval(() => { const now = Date.now(); for (const [t, s] of sessions) if (s.exp < now) sessions.delete(t); for (const [k, f] of fails) if (now - Math.max(f.until, f.last) > QUIET) fails.delete(k); }, 600e3).unref();

setInterval(() => { // unlock.bat drops this flag file when the owner is locked out of the site itself
  const f = path.join(DATA, 'UNLOCK.flag');
  if (!fs.existsSync(f)) return;
  try { fs.unlinkSync(f); fails.clear(); tx(() => audit('system', 'login.unlock', 'all', { via: 'console' })); log('Login locks cleared (unlock.bat)'); } catch (e) {}
}, 3000).unref();

// ---------- HTTP ----------
const readPub = f => fs.readFileSync(path.join(ROOT, 'public', f));
const STATIC = {
  '/': ['index.html', 'text/html; charset=utf-8'], '/index.html': ['index.html', 'text/html; charset=utf-8'],
  '/app.js': ['app.js', 'text/javascript; charset=utf-8'], '/style.css': ['style.css', 'text/css; charset=utf-8']
};
const FILES = {}; for (const [, v] of Object.entries(STATIC)) FILES[v[0]] = readPub(v[0]);
const SEC = {
  'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer', 'Cache-Control': 'no-store',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'"
};
function send(res, code, obj, headers) {
  const b = JSON.stringify(obj);
  res.writeHead(code, { ...SEC, 'Content-Type': 'application/json; charset=utf-8', ...(headers || {}) });
  res.end(b);
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = []; let n = 0;
    req.on('data', c => { n += c.length; if (n > 3e6) { reject(new Bad('الطلب كبير جدًا', 413)); req.destroy(); } else chunks.push(c); });
    req.on('end', () => {
      if (!n) return resolve({});
      if (!/^application\/json/i.test(req.headers['content-type'] || '')) return reject(new Bad('نوع الطلب غير مدعوم', 415));
      try { const j = JSON.parse(Buffer.concat(chunks).toString('utf8')); resolve(j && typeof j === 'object' ? j : {}); }
      catch (e) { reject(new Bad('بيانات غير صالحة')); }
    });
    req.on('error', reject);
  });
}
const itemOut = r => ({ id: r.id, cat: r.cat, name: r.name, batch: r.batch, exp: r.exp, prod: r.prod, code: r.code, made: r.made, unit: r.unit, per: r.per, qty: r.qty });
const userOut = r => ({ id: r.id, username: r.username, role: r.role, owner: !!r.owner, perms: permList(r), active: !!r.active, mustChange: !!r.must_change, createdAt: r.created_at });
const needOwner = u => { if (!u.owner) throw new Bad('غير مسموح: إدارة الحسابات للمالك فقط', 403); };
const need = (u, p) => { if (!can(u, p)) throw new Bad('غير مسموح: ليس لديك صلاحية لهذه العملية', 403); };

async function api(req, res, url) {
  const m = req.method, p = url.pathname;
  const body = ['POST', 'PATCH', 'DELETE'].includes(m) ? await readBody(req) : {};
  const ip = req.socket.remoteAddress || '?';

  if (m === 'POST' && p === '/api/login') {
    const name = typeof body.username === 'string' ? body.username.trim().slice(0, 64) : '', pw = typeof body.password === 'string' ? body.password.slice(0, 256) : '';
    const k1 = ip, k2 = ip + '|' + name.toLowerCase();
    if (isLocked(k1) || isLocked(k2)) throw new Bad('محاولات كثيرة. حاول بعد ' + lockLeftMin(k1, k2) + ' دقيقة أو اطلب من المالك يفك القفل', 429);
    const u = one('SELECT * FROM users WHERE username=?', name);
    const good = okPw(pw, u || DUMMY) && u && u.active;
    if (!good) {
      fail(k1, 20); fail(k2, 5);
      try { audit(name || '?', 'login.fail', ip, null); } catch (e) {}
      throw new Bad('اسم المستخدم أو كلمة المرور غير صحيحة', 401);
    }
    fails.delete(k2);
    const t = crypto.randomBytes(32).toString('hex');
    sessions.set(t, { uid: u.id, exp: Date.now() + IDLE });
    audit(u.username, 'login.ok', ip, null);
    return send(res, 200, { user: { username: u.username, role: u.role, owner: !!u.owner, perms: permList(u), mustChange: !!u.must_change } },
      { 'Set-Cookie': `sid=${t}; HttpOnly; SameSite=Strict; Path=/; Max-Age=${IDLE / 1000}` });
  }

  const a = auth(req);
  if (!a) return send(res, 401, { error: 'سجّل الدخول' });
  const me = a.u;
  if (m === 'POST' && p === '/api/logout') { sessions.delete(a.token); return send(res, 200, { ok: true }, { 'Set-Cookie': 'sid=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0' }); }
  if (m === 'GET' && p === '/api/me') return send(res, 200, { user: { username: me.username, role: me.role, owner: !!me.owner, perms: permList(me), mustChange: !!me.must_change } });

  if (m === 'POST' && p === '/api/password') {
    const row = one('SELECT * FROM users WHERE id=?', me.id);
    if (!okPw(String(body.old || ''), row)) throw new Bad('كلمة المرور الحالية غير صحيحة', 403);
    if (!validPw(body.new)) throw new Bad('كلمة المرور الجديدة لازم تكون 8 حروف على الأقل');
    if (body.new === body.old) throw new Bad('اختر كلمة مرور مختلفة عن الحالية');
    tx(() => { setPw(me.id, body.new, false); audit(me.username, 'password.change', me.username, null); });
    dropSessions(me.id, a.token);
    if (me.username === 'admin') try { fs.unlinkSync(path.join(DATA, 'FIRST-RUN-PASSWORD.txt')); } catch (e) {}
    return send(res, 200, { ok: true });
  }
  if (me.must_change) throw new Bad('لازم تغيّر كلمة المرور أولًا', 403);

  if (m === 'GET' && p === '/api/state') {
    const items = {}; for (const c of Object.keys(CATS)) items[c] = [];
    for (const r of all('SELECT * FROM items ORDER BY id')) items[r.cat].push(itemOut(r));
    const out = { items };
    if (can(me, 'users') || can(me, 'edit')) out.lastBackup = (one("SELECT v FROM meta WHERE k='last_backup'") || {}).v || null;
    return send(res, 200, out);
  }
  if (m === 'GET' && p === '/api/moves') {
    const r = queryMoves(url);
    return send(res, 200, { moves: r.rows, truncated: r.truncated, from: r.from, to: r.to });
  }
  if (m === 'GET' && p === '/api/report.xlsx') {
    const { rows, from, to } = queryMoves(url), f = filterRows(rows, url.searchParams.get('q')), sum = new Map();
    for (const r of f) { const k = [r.cat, r.name, r.batch, r.unit].join('|'), x = sum.get(k) || { r, in: 0, out: 0 }; x[r.type] = r2(x[r.type] + r.qty); sum.set(k, x); }
    const buf = xlsxOf([
      { name: 'الحركات', head: ['التاريخ', 'القسم', 'الصنف', 'رقم الباتش', 'النوع', 'الكمية', 'الوحدة', 'المستند', 'بواسطة', 'ملاحظة'], widths: [12, 14, 28, 14, 10, 10, 10, 24, 14, 30],
        rows: f.map(r => [r.date, CAT_TITLES[r.cat], r.name, r.batch, r.type === 'in' ? 'وارد' : 'صرف', r.qty, r.unit || '', r.doc_name || '', r.user, r.note || '']) },
      { name: 'ملخص الأصناف', head: ['القسم', 'الصنف', 'رقم الباتش', 'الوحدة', 'وارد', 'صرف', 'الصافي'], widths: [14, 28, 14, 10, 12, 12, 12],
        rows: [...sum.values()].map(x => [CAT_TITLES[x.r.cat], x.r.name, x.r.batch, x.r.unit || '', x.in, x.out, r2(x.in - x.out)]) },
    ]);
    res.writeHead(200, { ...SEC, 'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'Content-Disposition': `attachment; filename="report-${from}_to_${to}.xlsx"`, 'Content-Length': buf.length });
    return res.end(buf);
  }
  if (m === 'GET' && p === '/api/docs') {
    const kind = url.searchParams.get('kind'), base = 'SELECT d.id,d.kind,d.name,d.date,d.cat,d.note,d.user,(SELECT COUNT(*) FROM moves x WHERE x.doc_id=d.id) AS n FROM docs d';
    return send(res, 200, { docs: kind === 'invoice' || kind === 'receipt' ? all(base + ' WHERE d.kind=? ORDER BY d.id DESC LIMIT 2000', kind) : all(base + ' ORDER BY d.id DESC LIMIT 2000') });
  }
  const dm = /^\/api\/docs\/(\d+)$/.exec(p);
  if (m === 'GET' && dm) {
    const d = one('SELECT * FROM docs WHERE id=?', Number(dm[1])); if (!d) throw new Bad('المستند غير موجود', 404);
    return send(res, 200, { doc: d, lines: all('SELECT name,type,qty,unit,info FROM moves WHERE doc_id=? ORDER BY id', d.id).map(parseInfo) });
  }

  // ----- everything below needs a specific permission (checked on every request) -----

  if (m === 'GET' && p === '/api/locks') {
    need(me, 'users');
    const now = Date.now(), rows = [];
    for (const [k, f] of fails) if (f.until > now) { const i = k.indexOf('|'); rows.push({ key: k, ip: i < 0 ? k : k.slice(0, i), user: i < 0 ? '' : k.slice(i + 1), minutes: Math.ceil((f.until - now) / 60e3), level: f.lvl }); }
    return send(res, 200, { locks: rows });
  }
  if (m === 'POST' && p === '/api/locks/clear') {
    need(me, 'users');
    let n = 0;
    if (typeof body.key === 'string' && body.key) { if (fails.delete(body.key)) n = 1; }
    else { n = [...fails.values()].filter(f => f.until > Date.now()).length; fails.clear(); }
    tx(() => audit(me.username, 'login.unlock', body.key || 'all', { cleared: n }));
    return send(res, 200, { cleared: n });
  }
  if (m === 'POST' && p === '/api/backup') {
    if (!can(me, 'edit') && !can(me, 'users')) throw new Bad('غير مسموح: ليس لديك صلاحية لهذه العملية', 403);
    if (!cfg.backupDir) throw new Bad('مسار النسخ الاحتياطي (backupDir) لسه مش مظبوط في config.json');
    let dest;
    try { dest = backup(me.username); }
    catch (e) { log('MANUAL BACKUP FAILED: ' + e.message); throw new Bad('فشلت النسخة الاحتياطية. اتأكد إن الهارد الخارجي متوصل بالسيرفر، والتفاصيل في data\\server.log', 500); }
    return send(res, 200, { ok: true, file: path.basename(dest), at: new Date().toISOString() });
  }
  if (m === 'POST' && p === '/api/items') {
    need(me, 'edit');
    const it = cleanItem(body);
    const id = tx(() => {
      const ts = new Date().toISOString();
      const id = insertItem(it, ts);
      if (it.qty > 0) insMove({ ts, date: localDate(), cat: it.cat, item_id: id, name: it.name, type: 'in', qty: it.qty, unit: it.unit, note: 'رصيد افتتاحي', user: me.username, info: infoOf(it) });
      audit(me.username, 'item.add', `${it.cat}#${id} ${it.name}`, it);
      return id;
    });
    return send(res, 200, { id });
  }
  let mt;
  if (m === 'POST' && (mt = /^\/api\/items\/(\d+)\/move$/.exec(p))) {
    need(me, 'edit');
    const id = Number(mt[1]);
    const type = body.type === 'in' || body.type === 'out' ? body.type : null; if (!type) throw new Bad('نوع الحركة غير صالح');
    const note = optStr(body.note, 200);
    tx(() => {
      const it = one('SELECT * FROM items WHERE id=?', id); if (!it) throw new Bad('الصنف غير موجود', 404);
      let n = qtyOf(body.qty), bags = false;
      if (body.bag === 'كيس') { if (!it.per) throw new Bad('هذا الصنف مفيهوش حجم كيس'); bags = true; n = r2(n * it.per); }
      if (!(n > 0)) throw new Bad('الكمية لازم تكون أكبر من صفر');
      if (type === 'out' && n > it.qty) throw new Bad(`الكمية المطلوبة أكبر من المتاح (${it.qty} ${it.unit})`);
      const after = r2(it.qty + (type === 'in' ? n : -n));
      run('UPDATE items SET qty=? WHERE id=?', after, id);
      const nt = (bags ? `${body.qty} كيس` + (note ? ' — ' : '') : '') + note;
      insMove({ ts: new Date().toISOString(), date: localDate(), cat: it.cat, item_id: id, name: it.name, type, qty: n, unit: it.unit, note: nt, user: me.username, info: infoOf(it) });
      audit(me.username, 'move.' + type, `${it.cat}#${id} ${it.name}`, { qty: n, unit: it.unit, before: it.qty, after, note: nt });
    });
    return send(res, 200, { ok: true });
  }
  if (m === 'DELETE' && (mt = /^\/api\/items\/(\d+)$/.exec(p))) {
    need(me, 'edit');
    tx(() => {
      const it = one('SELECT * FROM items WHERE id=?', Number(mt[1])); if (!it) throw new Bad('الصنف غير موجود', 404);
      run('DELETE FROM items WHERE id=?', it.id);
      audit(me.username, 'item.delete', `${it.cat}#${it.id} ${it.name}`, itemOut(it));
    });
    return send(res, 200, { ok: true });
  }

  if (m === 'GET' && p === '/api/users') { need(me, 'users'); return send(res, 200, { users: all('SELECT * FROM users ORDER BY id').map(userOut) }); }
  // Only the owner can hand out (or touch) the 'users' permission; other account managers handle ordinary accounts only.
  const cleanPerms = (v, actor) => {
    if (v === undefined) v = [];
    if (!Array.isArray(v) || v.some(x => !PERMS.includes(x))) throw new Bad('صلاحيات غير صالحة');
    const s = PERMS.filter(x => v.includes(x));
    if (s.includes('users') && !actor.owner) throw new Bad('منح صلاحية إدارة الحسابات للمالك فقط', 403);
    return s;
  };
  if (m === 'POST' && p === '/api/users') {
    need(me, 'users');
    if (!validUser(body.username)) throw new Bad('اسم المستخدم: حروف إنجليزي وأرقام (من 3 إلى 32)');
    if (!validPw(body.password)) throw new Bad('كلمة المرور لازم تكون 8 حروف على الأقل');
    const perms = cleanPerms(body.perms, me);
    try { tx(() => createUser(body.username, body.password, roleOf(perms), true, me.username, perms.join(','))); }
    catch (e) { if (/UNIQUE/i.test(e.message)) throw new Bad('اسم المستخدم موجود بالفعل', 409); throw e; }
    return send(res, 200, { ok: true });
  }
  if (m === 'PATCH' && (mt = /^\/api\/users\/(\d+)$/.exec(p))) {
    need(me, 'users');
    const id = Number(mt[1]);
    tx(() => {
      const u = one('SELECT * FROM users WHERE id=?', id); if (!u) throw new Bad('الحساب غير موجود', 404);
      if (id === me.id) throw new Bad('مينفعش تعدّل حسابك بنفسك (لكلمة المرور استخدم زر "كلمة المرور" في الأعلى)');
      if (u.owner) throw new Bad('حساب المالك لا يمكن تعديله', 403);
      if (!me.owner && can(u, 'users')) throw new Bad('مينفعش تعدّل حساب مسؤول حسابات آخر', 403);
      if (body.password !== undefined) {
        if (!validPw(body.password)) throw new Bad('كلمة المرور لازم تكون 8 حروف على الأقل');
        setPw(id, body.password, true); dropSessions(id);
        audit(me.username, 'user.password.reset', u.username, null);
      }
      if (body.perms !== undefined) {
        const np = cleanPerms(body.perms, me), old = permList(u);
        run('UPDATE users SET perms=?, role=? WHERE id=?', np.join(','), roleOf(np), id);
        audit(me.username, 'user.perms', u.username, { from: old, to: np });
      }
      if (body.active !== undefined) {
        const act = body.active ? 1 : 0;
        run('UPDATE users SET active=? WHERE id=?', act, id);
        if (!act) dropSessions(id);
        audit(me.username, 'user.active', u.username, { from: !!u.active, to: !!act });
      }
    });
    return send(res, 200, { ok: true });
  }

  if (m === 'GET' && p === '/api/audit') {
    need(me, 'audit');
    const lim = Math.min(500, Math.max(1, Number(url.searchParams.get('limit')) || 200)), off = Math.max(0, Number(url.searchParams.get('offset')) || 0);
    return send(res, 200, { total: one('SELECT COUNT(*) AS n FROM audit').n, rows: all('SELECT id,ts,user,action,target,detail FROM audit ORDER BY id DESC LIMIT ? OFFSET ?', lim, off) });
  }
  if (m === 'GET' && p === '/api/audit/verify') { need(me, 'audit'); return send(res, 200, verifyAudit()); }

  if (m === 'POST' && p === '/api/invoices') {
    need(me, 'edit');
    const h = docHead(body), src = linesOf(body);
    const id = tx(() => {
      const want = new Map(), lines = [];
      src.forEach((l, i) => {
        const nm = str(l && l.name, `اسم الدواء (سطر ${i + 1})`), bt = str(l && l.batch, `رقم الباتش (سطر ${i + 1})`), q = qtyOf(l.qty, `الكمية (سطر ${i + 1})`);
        if (!(q > 0)) throw new Bad(`سطر ${i + 1}: الكمية لازم تكون أكبر من صفر`);
        const it = findItem('meds', { name: nm, batch: bt });
        if (!it) throw new Bad(`سطر ${i + 1}: مفيش دواء "${nm}" برقم باتش "${bt}"`);
        const w = want.get(it.id) || { it, q: 0 }; w.q = r2(w.q + q); want.set(it.id, w); lines.push({ it, q });
      });
      for (const { it, q } of want.values()) if (q > it.qty) throw new Bad(`"${it.name}" باتش ${it.batch}: المطلوب ${q} والمتاح ${it.qty} ${it.unit}`);
      const ts = new Date().toISOString();
      const did = Number(run('INSERT INTO docs(kind,name,date,cat,note,user,ts) VALUES(?,?,?,?,?,?,?)', 'invoice', h.name, h.date, 'meds', h.note, me.username, ts).lastInsertRowid);
      for (const { it, q } of lines) {
        run('UPDATE items SET qty=? WHERE id=?', r2(one('SELECT qty FROM items WHERE id=?', it.id).qty - q), it.id);
        insMove({ ts, date: h.date, cat: 'meds', item_id: it.id, name: it.name, type: 'out', qty: q, unit: it.unit, note: '', user: me.username, doc_id: did, info: infoOf(it) });
      }
      audit(me.username, 'invoice.add', `#${did} ${h.name}`, { date: h.date, lines: lines.map(x => ({ name: x.it.name, batch: x.it.batch, qty: x.q })) });
      return did;
    });
    return send(res, 200, { id });
  }
  if (m === 'POST' && p === '/api/receipts') {
    need(me, 'edit');
    const cat = body.cat; if (!CATS[cat]) throw new Bad('قسم غير معروف');
    const h = docHead(body), src = linesOf(body);
    const id = tx(() => {
      const ts = new Date().toISOString();
      const did = Number(run('INSERT INTO docs(kind,name,date,cat,note,user,ts) VALUES(?,?,?,?,?,?,?)', 'receipt', h.name, h.date, cat, h.note, me.username, ts).lastInsertRowid);
      const sum = [];
      src.forEach((l, i) => {
        const lab = `سطر ${i + 1}`;
        let it; try { it = cleanItem({ ...l, cat, qty: 0, per: null }); } catch (e) { throw new Bad(`${lab}: ${e.message}`); }
        let q = qtyOf(l.qty, `الكمية (${lab})`); if (!(q > 0)) throw new Bad(`${lab}: الكمية لازم تكون أكبر من صفر`);
        const ex = findItem(cat, it); let use;
        if (ex) {
          if (l.bag) { if (!ex.per) throw new Bad(`${lab}: الصنف ده مفيهوش حجم كيس`); q = r2(q * ex.per); }
          if (cat === 'meds' && ex.exp !== it.exp) throw new Bad(`${lab}: نفس الدواء والباتش موجود بتاريخ انتهاء مختلف (${ex.exp})`);
          run('UPDATE items SET qty=? WHERE id=?', r2(ex.qty + q), ex.id); use = ex;
        } else {
          if (l.bag) throw new Bad(`${lab}: الإدخال بالكيس متاح بس للأصناف الموجودة اللي ليها حجم كيس`);
          it.qty = q; use = { ...it, id: insertItem(it, ts) };
        }
        insMove({ ts, date: h.date, cat, item_id: use.id, name: use.name, type: 'in', qty: q, unit: use.unit, note: '', user: me.username, doc_id: did, info: infoOf(use) });
        sum.push({ name: use.name, qty: q, created: !ex });
      });
      audit(me.username, 'receipt.add', `#${did} ${h.name}`, { date: h.date, cat, lines: sum });
      return did;
    });
    return send(res, 200, { id });
  }
  if (m === 'POST' && p === '/api/import') {
    needOwner(me);
    const src = body.db && typeof body.db === 'object' ? body.db : body;
    if (!src.items || typeof src.items !== 'object' || !Array.isArray(src.log)) throw new Bad('الملف غير صالح');
    const rows = [], logs = [];
    for (const cat of Object.keys(src.items)) {
      if (!CATS[cat] || !Array.isArray(src.items[cat])) throw new Bad('قسم غير معروف في الملف: ' + cat);
      for (const x of src.items[cat]) { try { rows.push(cleanItem({ ...x, cat })); } catch (e) { throw new Bad(`صنف غير صالح في ${cat}: ${e.message}`); } }
    }
    if (rows.length > 20000 || src.log.length > 100000) throw new Bad('الملف كبير جدًا');
    for (const l of src.log) {
      if (!CATS[l && l.cat] || (l.type !== 'in' && l.type !== 'out')) throw new Bad('سجل حركات غير صالح');
      logs.push({ date: dateOf(l.date), cat: l.cat, name: str(l.name, 'name'), type: l.type, qty: qtyOf(l.qty), unit: optStr(l.unit, 30), note: optStr(l.note) });
    }
    tx(() => {
      if (one('SELECT 1 AS x FROM items')) throw new Bad('الاستيراد مسموح فقط لو النظام فاضي من الأصناف', 409);
      const ts = new Date().toISOString();
      for (const it of rows) insertItem(it, ts);
      for (const l of logs) run('INSERT INTO moves(ts,date,cat,item_id,name,type,qty,unit,note,user) VALUES(?,?,?,?,?,?,?,?,?,?)',
        ts, l.date, l.cat, null, l.name, l.type, l.qty, l.unit, l.note, '(استيراد)');
      audit(me.username, 'import', '', { items: rows.length, moves: logs.length });
    });
    return send(res, 200, { items: rows.length, moves: logs.length });
  }
  throw new Bad('غير موجود', 404);
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://localhost');
    if (req.method === 'GET' && STATIC[url.pathname]) {
      const [f, type] = STATIC[url.pathname];
      res.writeHead(200, { ...SEC, 'Content-Type': type }); return res.end(FILES[f]);
    }
    if (!url.pathname.startsWith('/api/')) return send(res, 404, { error: 'غير موجود' });
    if (req.method !== 'GET' && req.headers['x-requested-with'] !== 'fetch') return send(res, 403, { error: 'طلب مرفوض' });
    await api(req, res, url);
  } catch (e) {
    if (e instanceof Bad) return send(res, e.code, { error: e.message });
    log('ERROR ' + (e && e.stack || e));
    if (!res.headersSent) send(res, 500, { error: 'حدث خطأ في السيرفر' });
  }
});
server.on('clientError', (e, s) => s.destroy());
server.listen(cfg.port, '0.0.0.0', () => log(`Pharmacia inventory running on port ${cfg.port}`));
process.on('uncaughtException', e => { log('FATAL ' + (e && e.stack || e)); process.exit(1); });
