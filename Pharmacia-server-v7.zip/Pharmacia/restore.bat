@echo off
net session >nul 2>&1
if errorlevel 1 (echo Please right-click this file and choose "Run as administrator" & pause & exit /b 1)
cd /d "%~dp0"
echo Stopping the server...
schtasks /end /tn "PharmaciaInventory" >nul 2>&1
taskkill /f /im node.exe >nul 2>&1
timeout /t 3 /nobreak >nul
node restore.js
echo.
echo Starting the server again...
schtasks /run /tn "PharmaciaInventory" >nul 2>&1
if errorlevel 1 echo Autostart task not found - start the server manually with start.bat
pause
