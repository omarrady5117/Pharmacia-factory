@echo off
cd /d "%~dp0"
node server.js --backup
if errorlevel 1 (echo BACKUP FAILED - see data\server.log) else (echo Backup OK)
if "%1"=="" pause
