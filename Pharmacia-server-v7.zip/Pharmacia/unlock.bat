@echo off
cd /d "%~dp0"
if not exist data mkdir data
type nul > data\UNLOCK.flag
echo Done. All login locks will be cleared within a few seconds.
pause
