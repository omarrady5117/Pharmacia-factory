@echo off
cd /d "%~dp0"
set /p U=Username to reset: 
node server.js --reset-password "%U%"
pause
