@echo off
net session >nul 2>&1
if errorlevel 1 (echo Please right-click this file and choose "Run as administrator" & pause & exit /b 1)
cd /d "%~dp0"
schtasks /create /tn "PharmaciaBackup" /tr "\"%~dp0backup.bat\" auto" /sc daily /st 02:00 /ru SYSTEM /rl HIGHEST /f
echo.
echo Done. A backup will run every day at 02:00.
pause
