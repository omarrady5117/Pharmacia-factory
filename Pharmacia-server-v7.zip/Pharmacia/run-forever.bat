@echo off
cd /d "%~dp0"
if not exist data mkdir data
:loop
node server.js >> data\console.log 2>&1
timeout /t 5 /nobreak >nul
goto loop
