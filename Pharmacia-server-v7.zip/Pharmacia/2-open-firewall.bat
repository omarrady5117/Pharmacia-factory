@echo off
net session >nul 2>&1
if errorlevel 1 (echo Please right-click this file and choose "Run as administrator" & pause & exit /b 1)
netsh advfirewall firewall add rule name="Pharmacia Inventory" dir=in action=allow protocol=TCP localport=3000 profile=domain,private
echo.
echo Done. Port 3000 is open for the company network only.
pause
