'use strict';
// Restore a backup made by the server (pharmacia-*.db). Run through restore.bat while the server is stopped.
const fs = require('node:fs'), path = require('node:path'), readline = require('node:readline'), crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

const ROOT = __dirname;
const cfg = { dataDir: 'data', backupDir: '' };
try { Object.assign(cfg, JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'))); }
catch (e) { console.log('Cannot read config.json: ' + e.message); process.exit(1); }
const DATA = path.resolve(ROOT, cfg.dataDir);
const LIVE = path.join(DATA, 'pharmacia.db'), TMP = path.join(DATA, 'restore-tmp.db');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: false });
const lines = rl[Symbol.asyncIterator]();
const ask = async q => { process.stdout.write(q); const r = await lines.next(); return r.done ? '' : String(r.value).trim(); };
const two = n => String(n).padStart(2, '0');
const stamp = d => `${d.getFullYear()}-${two(d.getMonth() + 1)}-${two(d.getDate())}_${two(d.getHours())}${two(d.getMinutes())}${two(d.getSeconds())}`;
const cleanTmp = () => { for (const s of ['', '-wal', '-shm', '-journal']) { try { fs.unlinkSync(TMP + s); } catch (e) {} } };
const sha = s => crypto.createHash('sha256').update(s).digest('hex');
async function main() {
  if (!cfg.backupDir) { console.log('backupDir is empty in config.json - set it first.'); return 1; }
  let files;
  try {
    files = fs.readdirSync(cfg.backupDir).filter(f => /^pharmacia-[\d_-]+\.db$/.test(f))
      .map(f => { const st = fs.statSync(path.join(cfg.backupDir, f)); return { f, t: st.mtime, size: st.size }; })
      .sort((a, b) => b.t - a.t).slice(0, 20);
  } catch (e) { console.log('Cannot read the backup folder (' + cfg.backupDir + '): ' + e.message + '\nIs the external drive connected?'); return 1; }
  if (!files.length) { console.log('No backups (pharmacia-*.db) found in ' + cfg.backupDir); return 1; }
  console.log('\nBackups found (newest first):\n');
  files.forEach((x, i) => console.log(`  [${i + 1}]  ${x.t.getFullYear()}-${two(x.t.getMonth() + 1)}-${two(x.t.getDate())} ${two(x.t.getHours())}:${two(x.t.getMinutes())}   ${(x.size / 1048576).toFixed(2)} MB   ${x.f}`));
  const n = parseInt(await ask('\nType the number of the backup to restore (or 0 to cancel): '), 10);
  if (!n || n < 1 || n > files.length) { console.log('Cancelled. Nothing was changed.'); return 0; }
  const pick = files[n - 1];

  // 1) copy the backup next to the live data and check it BEFORE touching anything
  cleanTmp();
  try {
    fs.copyFileSync(path.join(cfg.backupDir, pick.f), TMP);
    const t = new DatabaseSync(TMP);
    const chk = Object.values(t.prepare('PRAGMA integrity_check').get())[0];
    if (chk !== 'ok') throw new Error('integrity check failed: ' + chk);
    for (const tb of ['users', 'items', 'moves', 'audit', 'meta']) if (!t.prepare("SELECT 1 AS x FROM sqlite_master WHERE type='table' AND name=?").get(tb)) throw new Error('table missing: ' + tb);
    if (!t.prepare("SELECT 1 AS x FROM users WHERE role='admin' AND active=1").get()) throw new Error('no active admin account inside this backup');
    const cnt = t.prepare('SELECT (SELECT COUNT(*) FROM items) AS i, (SELECT COUNT(*) FROM moves) AS m, (SELECT COUNT(*) FROM users) AS u').get();
    console.log(`\nThis backup contains: ${cnt.i} items, ${cnt.m} movements, ${cnt.u} accounts.`);
    t.close();
  } catch (e) { cleanTmp(); console.log('\nThis file is NOT a valid backup: ' + e.message + '\nNothing was changed.'); return 1; }

  console.log('\nWARNING: everything recorded AFTER this backup was taken will be lost.');
  console.log('A copy of the current data will be saved first, so you can undo this.');
  if ((await ask('Type YES (capital letters) to continue: ')) !== 'YES') { cleanTmp(); console.log('Cancelled. Nothing was changed.'); return 0; }

  // 2) keep a copy of the current data
  const saved = path.join(DATA, 'before-restore-' + stamp(new Date()));
  fs.mkdirSync(saved, { recursive: true });
  for (const s of ['', '-wal', '-shm']) if (fs.existsSync(LIVE + s)) fs.copyFileSync(LIVE + s, path.join(saved, 'pharmacia.db' + s));

  // 3) record the restore in the audit log of the restored database, then swap it in
  const t = new DatabaseSync(TMP);
  const prev = (t.prepare('SELECT hash FROM audit ORDER BY id DESC LIMIT 1').get() || {}).hash || '0';
  const ts = new Date().toISOString(), detail = JSON.stringify({ file: pick.f, via: 'restore.bat' });
  t.prepare('INSERT INTO audit(ts,user,action,target,detail,prev_hash,hash) VALUES(?,?,?,?,?,?,?)')
    .run(ts, 'system', 'restore', pick.f, detail, prev, sha([prev, ts, 'system', 'restore', pick.f, detail].join('|')));
  t.close();
  for (const s of ['-wal', '-shm', '-journal']) { try { fs.unlinkSync(TMP + s); } catch (e) {} }
  for (const s of ['', '-wal', '-shm']) { try { fs.unlinkSync(LIVE + s); } catch (e) { if (e.code !== 'ENOENT') throw e; } }
  fs.renameSync(TMP, LIVE);
  console.log('\nRestore DONE from: ' + pick.f);
  console.log('Previous data was saved in: ' + saved);
  return 0;
}
main().then(c => { rl.close(); process.exit(c); }).catch(e => { cleanTmp(); console.log('\nRestore FAILED: ' + e.message + '\nIf the live data looks wrong, copy the files from the latest before-restore-* folder inside data back into data.'); process.exit(1); });
