@echo off
cd /d "%~dp0"
set /p U=Admin username to become the owner: 
node server.js --make-owner "%U%"
pause
