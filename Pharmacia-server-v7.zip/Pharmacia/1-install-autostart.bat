@echo off
net session >nul 2>&1
if errorlevel 1 (echo Please right-click this file and choose "Run as administrator" & pause & exit /b 1)
cd /d "%~dp0"
schtasks /create /tn "PharmaciaInventory" /tr "\"%~dp0run-forever.bat\"" /sc onstart /ru SYSTEM /rl HIGHEST /f
schtasks /run /tn "PharmaciaInventory"
echo.
echo Done. The server now starts automatically with Windows.
pause
